
###   This script compute the gradient penalty for the QBiGAN 
###   The latent vector produced by the encoder is taken into account
import torch
import torch.autograd as autograd

########  V 4.0 
#########################################################################
################new function takes into account z for QBIGAN

def compute_gradient_penalty(critic, encoder, latent_dim, real_samples, fake_samples, z, device):
    batch_size, C, W, H = real_samples.shape
    epsilon = torch.rand(batch_size, 1, 1, 1).repeat(1, C, W, H)
    interpolated_images = (epsilon * real_samples + ((1 - epsilon) * fake_samples)).requires_grad_(True)

    # Interpolate the latent vector in a similar manner
    if z is not None:
        epsilon_z = torch.rand(batch_size, z.shape[1])
        interpolated_z = (epsilon_z * (encoder(real_samples,latent_dim)) + ((1 - epsilon_z) * z)).requires_grad_(True)
    else:
        interpolated_z = None

    # Pass both interpolated images and latent vectors to the critic
    if interpolated_z is not None:
        interpolated_scores = critic(interpolated_images, interpolated_z)
    else:
        interpolated_scores = critic(interpolated_images)
        
    # Create a tensor of ones for gradient computation, matching the device and shape of d_interpolates
    grad_outputs = torch.ones_like(interpolated_scores, requires_grad=False)
    
    # Compute gradients w.r.t. interpolates
    gradients = torch.autograd.grad(
        outputs=interpolated_scores,
        inputs=[interpolated_images, interpolated_z],
        grad_outputs=grad_outputs,
        create_graph=True,
        retain_graph=True,
        only_inputs=True,
    )[0]
    
    gradients = gradients.view(gradients.shape[0], -1)
    gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
    return gradient_penalty

