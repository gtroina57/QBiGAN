#### This script contains the model of the QBiGAN
#### Critic Encoder Generator


import pennylane as qml
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class PQWGAN_CC_CE():
    def __init__(self, image_size, channels, n_generators, n_qubits, n_ancillas, n_layers, patch_shape, latent_dim):
        self.image_shape = (channels, image_size, image_size)
    
        self.encoder = self.ClassicalEncoder(self.image_shape, latent_dim)
        self.critic = self.ClassicalCritic(self.image_shape, latent_dim)
        self.generator = self.QuantumGenerator(n_generators, n_qubits, n_ancillas, n_layers, self.image_shape, patch_shape)

#######  New Encoder for the QBiGAN  architecture
    class ClassicalEncoder(nn.Module):
        def __init__(self, image_shape, latent_dim):
            super().__init__()
            self.image_shape = image_shape
            self.latent_dim = latent_dim

            # Define linear layers
            self.fe1 = nn.Linear(int(np.prod(self.image_shape)), np.prod(self.image_shape))
            self.fe2 = nn.Linear(np.prod(self.image_shape), np.prod(self.image_shape))
            self.fe3 = nn.Linear(np.prod(self.image_shape), latent_dim)

            # Define batch normalization layer after the second linear layer
            self.bn1 = nn.BatchNorm1d(np.prod(self.image_shape))

        def forward(self, x, latent_dim):
            # Flatten the input
            x = x.view(x.shape[0], -1)
            # Apply first linear layer and activation
            x = F.leaky_relu(self.fe1(x), 0.2)
            # Apply second linear layer and activation
            x = self.fe2(x)
            x = F.leaky_relu(self.bn1(x), 0.2)  # Apply batch normalization after the second linear layer
            # Apply third linear layer
            x = self.fe3(x)
            x = torch.tanh(x)  # Ensure output is in the range [-1, 1]
            return x 
            
##########  Modified Critic for the QBIGAN
##########  It is possible to replicate the latent vector n times
    class ClassicalCritic(nn.Module):       
        def __init__(self, image_shape, latent_dim):
            super().__init__()
            self.image_shape = image_shape
            self.latent_dim = latent_dim
           
            # Adjust the input size to account for the replicated last 8 elements
            # Assuming the replication factor is 6 to approximate the last 8 elements being treated as 50
            self.network = nn.Sequential(
                nn.Linear(256 + latent_dim * 3, 256),  # 16*16 = 256 elements from main part + 3 elements replicated 3 times
                nn.LeakyReLU(negative_slope=0.2),
                nn.Linear(256, 128),
                nn.LeakyReLU(negative_slope=0.2),
                
                nn.Linear(128, 1)  
            )

        def forward(self, x, z):
            x = x.view(x.shape[0], -1)  # Flatten the image
            # Replicate the last latent vector elements to increase their emphasis
            replicated_last_latent = z.repeat(1, 3)  # Replicates the elements along the second dimension

            enhanced_input = torch.cat((x, replicated_last_latent), dim=1)

            # Process the enhanced input through the network
            output = self.network(enhanced_input)
            return output

##########  Generator for the QBIGAN (no modifications in respect to Tsang's software)

    class QuantumGenerator(nn.Module):
        def __init__(self, n_generators, n_qubits, n_ancillas, n_layers, image_shape, patch_shape):
            super().__init__()
            self.n_generators = n_generators
            self.n_qubits = n_qubits
            self.n_ancillas = n_ancillas
            self.n_layers = n_layers
            ##self.q_device = qml.device("lightning.qubit", wires=n_qubits)
            self.q_device = qml.device("default.qubit", wires=n_qubits)
            self.params = nn.ParameterList([nn.Parameter(torch.rand(n_layers, n_qubits, 3), requires_grad=True) for _ in range(n_generators)])
            self.qnode = qml.QNode(self.circuit, self.q_device, interface="torch")

            self.image_shape = image_shape
            self.patch_shape = patch_shape

        def forward(self, x):
            special_shape = bool(self.patch_shape[0]) and bool(self.patch_shape[1])
            patch_size = 2 ** (self.n_qubits - self.n_ancillas)
            image_pixels = self.image_shape[2] ** 2
            pixels_per_patch = image_pixels // self.n_generators
            if special_shape and self.patch_shape[0] * self.patch_shape[1] != pixels_per_patch:
                raise ValueError("patch shape and patch size dont match!")
            output_images = torch.Tensor(x.size(0), 0).to(device)

            for sub_generator_param in self.params:
                patches = torch.Tensor(0, pixels_per_patch).to(device)
                for item in x:
                    item = item.to(device) 
                for item in x:
                    sub_generator_out = self.partial_trace_and_postprocess(item, sub_generator_param).float().unsqueeze(0).to(device)
                    if pixels_per_patch < patch_size:
                        sub_generator_out = sub_generator_out[:,:pixels_per_patch]
                    patches = torch.cat((patches, sub_generator_out))
                output_images = torch.cat((output_images, patches), 1)

            if special_shape:
                final_out = torch.zeros(x.size(0), *self.image_shape)
                for i,img in enumerate(output_images):
                    for patches_done, j in enumerate(range(0, img.shape[0], pixels_per_patch)):
                        patch = torch.reshape(img[j:j+pixels_per_patch], self.patch_shape)
                        starting_h = ((patches_done * self.patch_shape[1]) // self.image_shape[2]) * self.patch_shape[0]
                        starting_w = (patches_done * self.patch_shape[1]) % self.image_shape[2]
                        final_out[i, 0, starting_h:starting_h+self.patch_shape[0], starting_w:starting_w+self.patch_shape[1]] = patch
            else:
                final_out = output_images.view(output_images.shape[0], *self.image_shape)
            return final_out

        def circuit(self, latent_vector, weights):
            for i in range(self.n_qubits):
                qml.RY(latent_vector[i], wires=i)

            for i in range(self.n_layers):
                for j in range(self.n_qubits):
                    qml.Rot(*weights[i][j], wires=j)

                for j in range(self.n_qubits-1):
                    qml.CNOT(wires=[j, j+1])

            return qml.probs(wires=list(range(self.n_qubits)))

        def partial_trace_and_postprocess(self, latent_vector, weights):
            probs = self.qnode(latent_vector, weights)
            probs_given_ancilla_0 = probs[:2**(self.n_qubits - self.n_ancillas)]
            post_measurement_probs = probs_given_ancilla_0 / torch.sum(probs_given_ancilla_0)

            # uncomment to check outputs of circuit
            # print(torch.sum(post_measurement_probs[:28]), torch.sum(post_measurement_probs[28:]))

            # normalise image between [-1, 1]
            post_processed_patch = ((post_measurement_probs / torch.max(post_measurement_probs)) - 0.5) * 2
            return post_processed_patch